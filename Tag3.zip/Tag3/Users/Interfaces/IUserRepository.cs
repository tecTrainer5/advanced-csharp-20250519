﻿namespace Users.Interfaces;

public interface IUserRepository
{
    User GetById(int id);
    bool Save(User user);
}
