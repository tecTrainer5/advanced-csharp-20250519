﻿using Users.Interfaces;

namespace Users;

public class UserService
{
    private readonly IUserRepository userRepository;

    public UserService(IUserRepository userRepository)
    {
        this.userRepository = userRepository;
    }

    public bool UpdateUserEmail(int userId,string email)
    {
        if (string.IsNullOrEmpty(email) || !email.Contains("@"))
            return false;

        var user = userRepository.GetById(userId);
        if (user is null)
            return false;

        user.Email = email;
        return userRepository.Save(user);
    }
}
