﻿namespace Cancelation
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            var cts = new CancellationTokenSource();
            var token = cts.Token;


            var task = DoSomething(token);

            for (int i = 0; i < 10; i++) {
                Thread.Sleep(100);
            }

            cts.Cancel();

            try
            {
                await task;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            //try
            //{
            //    task.Wait();
            //}
            //catch (Exception ex) {
            //    Console.WriteLine(ex);
            //}

            Thread.Sleep(1000);

            Console.WriteLine($"Canceld: {task.IsCanceled}");
            Console.WriteLine($"Successfully: {task.IsCompletedSuccessfully}");
            Console.WriteLine($"Completed: {task.IsCompleted}");
            Console.WriteLine($"Faulted: {task.IsFaulted}");
            Console.WriteLine($"Status: {task.Status}");
            Console.WriteLine($"Task EX: {task.Exception?.Message}");

            Console.WriteLine("Application done!");
        }

        static async Task DoSomethingIntern(CancellationToken token)
        {
            await DoSomething(token);

            // some fancy code
            token.ThrowIfCancellationRequested();
        }

        [Obsolete("We implemented a new version 1.1")]
        static async Task DoSomething(CancellationToken token)
        {
            try
            {
                for (int i = 0; i < 100000; ++i)
                {
                    token.ThrowIfCancellationRequested();

                    //if (token.IsCancellationRequested)
                    //{
                    //    Console.WriteLine("Cancel operation!");
                    //    return;
                    //}

                    Console.WriteLine(i);
                    await Task.Delay(100);
                }
            }
            catch (OperationCanceledException ex)
            {
                // tear down our stuff
                throw;
            }
            catch (Exception ex) {
                // handle the error
            }

        }
    }
}
