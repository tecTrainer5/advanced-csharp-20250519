﻿using Moq;
using Users.Interfaces;

namespace Users.Test;

public class UserServiceTests : IDisposable
{
    private readonly Mock<IUserRepository> _userRepoMock;

    private readonly User _user;

    public UserServiceTests()
    {
        _user = new User() { Id = 1, Email = "alex@example.com" };
        _userRepoMock = new Mock<IUserRepository>();
        _userRepoMock.Setup(repo => repo.GetById(1)).Returns(_user);
        _userRepoMock.Setup(repo => repo.Save(It.IsAny<User>())).Returns(true);
    }

    public void Dispose()
    {
        // teardown goes here
    }

    [Fact]
    public void UpdateUseEMamail_ValidEmail_ReturnsTrue()
    {
        // Arrange
        var service = new UserService(_userRepoMock.Object);

        // Act
        bool result = service.UpdateUserEmail(1, "new@example.com");

        // Assert
        Assert.True(result );
        _userRepoMock.Verify(repo => repo.Save(It.Is<User>(u => u.Email == "new@example.com")),Times.Once);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("invalid-email")]
    //[InlineData("invalid@email.com")] // nehmen wir nicht -> weil valid
    public void UpdateUserEmail_InvalidEmail_ReturnsFalse(string email)
    {
        // Arrange
        var service = new UserService(_userRepoMock.Object);

        // Act
        bool result = service.UpdateUserEmail(1, email);

        // Assert
        Assert.False(result);
        _userRepoMock.Verify(repo => repo.Save(It.IsAny<User>()), Times.Never);
        _userRepoMock.Verify(repo => repo.GetById(It.IsAny<int>()), Times.Never);
    }
}
