﻿using SimpleCalculator;

namespace Cancelation.Test
{
    public class CalculatorTests
    {
        private readonly Calculator _calculator;

        public CalculatorTests()
        {
            _calculator = new Calculator();
        }


        [Fact]
        public void Add_TwoNubers_ReturnsSum()
        {
            // Arrange
            int a = 5, b = 3;

            // Act
            int result = _calculator.Add(a, b);

            // Assert
            Assert.Equal(8, result);
        }

        [Theory]
        [InlineData(10,2,5)]
        [InlineData(10,4,2.5)]
        public void Divide_TwoNubes_ReturnsTimes(int a, int b,double expected)
        {
            //Act
            double result = _calculator.Divide(a, b);

            //Assert
            Assert.Equal(expected, result);
        }

        [Fact]
        public void Divide_DivideByZero_ThrowsDividedByZeroException()
        {
            // Arrange
            int a = 10, b = 0;

            // Act & Assert
            Assert.Throws<DivideByZeroException>(() => _calculator.Divide(a, 0));
        }

        [Theory]
        [InlineData(10, 2,20)]
        [InlineData(10, 4, 40)]
        [InlineData(10, -4, -40)]
        [InlineData(10, 0, 0)]
        public void Multiply_TwoNubes_ReturnsResult(int a, int b, int expected)
        {
            //Act
            int result = _calculator.Multiply(a, b);

            //Assert
            Assert.Equal(expected, result);
        }
    }
}
