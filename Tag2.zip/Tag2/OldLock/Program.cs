﻿namespace OldLock
{
    internal class Program
    {
        public static int _counter;

        public static readonly object _lock = new object();

        static void Main(string[] args)
        {
            List<int> werte = Enumerable.Range(0,20).ToList();

            Console.WriteLine($"Counter: {_counter}");
            Parallel.For(0,200,new ParallelOptions { MaxDegreeOfParallelism = 10 },(a) => {

                lock(_lock)
                {
                    werte[a % 20] += a;
                }

                _counter = a;
            },);
            Console.WriteLine($"Counter: {_counter}");

            foreach(int i in werte)
            {
                Console.WriteLine(i);
            }


            //for (int i = 0; i < 200; ++i) {

            //}
        }
    }
}
