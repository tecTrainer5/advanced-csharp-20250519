﻿using System.ComponentModel;
using System.Threading.Tasks;

namespace ManualThreading
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            // Create a new thread with a ThreadStart delegate
            Thread workerThread = new Thread(new ThreadStart(DoWork));
            workerThread.IsBackground = true; // erhält die app nicht am leben wegen diesem thread
            // wenn false (default) => warte der prozess auf den thread

            #region Ausfulg zu delegates
            //DoSomething((a, b) => a + b);
            DoSomething(AddMethod);



            IEnumerable<int> daten = [1, 2, 3, 4, 5, 6];
            // Func ist ein fertiges delegate von .NET
            Func<int> generate = () => 10;
            // Action ebenfalls
            // Predicate            
            var gerade = daten.Where((x) => x % 2 == 0).ToList();
            #endregion

            workerThread.Start();
            //DoWork();

            for (int i = 0;i < 5; i++)
            {
                Console.WriteLine($"Main thread working: {i}");
                Thread.Sleep(100);
            }

            // wartet immer egal ob IsBackground true oder false ist
            //workerThread.Join();

            Console.WriteLine("All work completed");
        }

        static void DoWork()
        {
            Console.WriteLine($"Worker Thread: {Thread.CurrentThread.ManagedThreadId}");

            // simulate work
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Worker thread working: {i}");
                Thread.Sleep(200);
            }

            Console.WriteLine("Worker thread completed");
        }

        delegate int Add(int x, int y);

        static void DoSomething(Add add) {
            Console.WriteLine(add(1,2));
        }

        static int AddMethod(int x, int y) { 
            return x + y;
        }
    }
}
