﻿namespace MutexGlobal
{
    internal class Program
    {
        static string mutexName = "MyFancyApp";

        static void Main(string[] args)
        {
            Mutex mutex = new Mutex(true, mutexName, out bool createdNew);

            if(!createdNew)
            {
                Thread.Sleep(10000);
                Console.WriteLine("App is already running!");
                return;
            }

            while (true) { Thread.Sleep(200); }
        }
    }
}
