﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TPL
{
    internal class APIService
    {
        public async Task<string> GetContent(string url)
        {
            try
            {
                await Task.Yield();
                var content = "Some fancy web content";
                //content = DateTime.Now.ToString() + ": " + content;

                return content;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Download failed: {ex.Message}");
                throw;
            }
        }

        public ValueTask<string> GetContentOhneAwait(string url)
        {
            try
            {
                var content = "Some fancy web content";
                //content = DateTime.Now.ToString() + ": " + content;

                return ValueTask.FromResult(content);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Download failed: {ex.Message}");
                throw;
            }
        }
    }
}
