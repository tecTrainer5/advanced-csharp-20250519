﻿namespace TPL
{
    internal class Program
    {
        // async main ist  mittlerweile möglich
        //static async void Main(string[] args)
        static void Main(string[] args)
        {
            var cts = new CancellationTokenSource();
            var taskExample = DownloadContentAsync("https://www.example.com", cts.Token);
            //var taskGoogle = DownloadContentAsync("https://www.google.com",cts.Token);

            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Main is working");
                Thread.Sleep(300);
            }

            #region Multiple
            //var tasks = new Task<string>[] { taskExample, taskGoogle };
            ////Task.WaitAll(taskExample, taskGoogle);
            //var index = Task.WaitAny(tasks);

            //var content = tasks[index].Result;
            //var webContentGoogle = taskGoogle.Result;
            #endregion

            //var webContent = taskExample.Result;

            //Console.WriteLine(webContent);

            var adressen = new List<string>() { "https://orf.at", "https://example.com", "https://google.com" };
            var aufgaben = new List<Task<string>>();


            // oder per parallel foreach
            foreach (var adress in adressen)
            {
                //aufgaben.Add();
                DownloadContentAsync(adress, cts.Token)
                    .ContinueWith(task => { _ = task.Result; }) // wenn fertig mache das folgende
                    .ConfigureAwait(false); // main thread uebernimmt nicht wieder -> sondern der bishere andere thread
            }

            //var index = -1;
            //while(index != -1)
            //{
            //    index = Task.WaitAny(aufgaben.ToArray());
            //    var x = aufgaben[index];
            //    var x.Result
            //}

            var fakeContent2 = new APIService().GetContentOhneAwait("asdf").Result;

            DownloadContentAsyncError("fake", cts.Token);
        }

        static async Task<string> DownloadContentAsync(string url, CancellationToken cancellationToken)
        {
            Console.WriteLine($"Starting download from {url}");

            try
            {
                using var client = new HttpClient();

                var content = await client.GetStringAsync(url, cancellationToken);
                content = DateTime.Now.ToString() + ": " + content;

                throw new Exception("Fake EX");

                return content;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Download failed: {ex.Message}");
                throw;
            }
        }

        static async void DownloadContentAsyncError(string url, CancellationToken cancellationToken)
        {
            Console.WriteLine($"Starting download from {url}");

            //try
            //{
                using var client = new HttpClient();

                var content = await client.GetStringAsync(url, cancellationToken);
                //content = DateTime.Now.ToString() + ": " + content;

                throw new Exception("Fake EX");

                //return content;
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine($"Download failed: {ex.Message}");
                //throw;
            //}
        }
    }
}
