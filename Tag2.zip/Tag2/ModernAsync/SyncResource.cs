﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModernAsync
{
    internal class SyncResource : IDisposable
    {
        public SyncResource()
        {
            Console.WriteLine("Sync Resource erstellt");
        }

        public void Dispose()
        {
            Console.WriteLine("Sync disposable");
        }
    }
}
