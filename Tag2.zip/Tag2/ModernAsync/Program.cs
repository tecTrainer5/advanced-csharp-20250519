﻿namespace ModernAsync
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            await foreach(var item in GenerateNumber())
            {
                Console.WriteLine(item);
            }

            // recap usig & IDisposable
            using var resource = new SyncResource();

            using (var res2 = new SyncResource())
            {
                Console.WriteLine("resouce used");
            };

            // async disposable
            await using var x = new AsyncResource();
            await using (var res2 = new AsyncResource())
            {
                Console.WriteLine("resouce used");
            };
        }

        static async IAsyncEnumerable<int> GenerateNumber()
        {
            for(int i = 0; i <= 10; ++i)
            {
                await Task.Delay(1000);
                yield return i;
            }
        }

        static async Task<int> ComputValueAsync(int key,Dictionary<int,int> cache)
        {
            Console.WriteLine($"Computing value for {key} ...");
            await Task.Delay(500);
            int result = key * 10;
            cache[key] = result;
            return result;
        }

        static ValueTask<int> GetValueWithCachingAsync(int key, Dictionary<int, int> cache)
        {
            if(cache.TryGetValue(key,out int reslult))
            {
                Console.WriteLine($"Cache hit for key {key}");
                return new ValueTask<int>(reslult);
            }

            return new ValueTask<int>(ComputValueAsync(key, cache));
        }

        static Task<int> GetValueWithCachingAsync2(int key, Dictionary<int, int> cache)
        {
            if (cache.TryGetValue(key, out int reslult))
            {
                Console.WriteLine($"Cache hit for key {key}");
                return Task.FromResult(reslult);
            }

            return ComputValueAsync(key, cache);
        }


    }
}
