﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModernAsync
{
    internal class AsyncResource : IAsyncDisposable
    {
        public async ValueTask DisposeAsync()
        {
            Console.WriteLine("Starting to dispose ...");
            await Task.Delay(100);
            Console.WriteLine("Async resource disposed");
        }
    }
}
