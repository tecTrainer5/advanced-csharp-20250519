﻿using System.Formats.Asn1;
using System.Net;

namespace APM
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var request = HttpWebRequest.Create("https://www.example.com/");

            Console.WriteLine("Starting async request...");

            // begin async operation
            //var asyncResult = request.BeginGetResponse(new AsyncCallback(GetResponseCallback), request);
            var asyncResult = request.BeginGetResponse(null, request);

            // Do your main work here
            Console.WriteLine("Main thread continues working...");

            Console.WriteLine($"AsyncState type: {asyncResult.AsyncState?.GetType().FullName}");

            // Wait for the WaitHandle to be signaled
            asyncResult.AsyncWaitHandle.WaitOne();
            //GetResponseCallback(asyncResult);


            Console.WriteLine("Main method complete.");
        }

        private static void GetResponseCallback(IAsyncResult asyncResult) {
            try
            {
                var request = asyncResult.AsyncState as WebRequest;
                var response = request.EndGetResponse(asyncResult);

                using Stream stream = response.GetResponseStream();
                using StreamReader reader = new StreamReader(stream);
                string content = reader.ReadToEnd();
                Console.WriteLine($"Response length: {content.Length} characters");
                Console.WriteLine($"First 100 char: {content.Substring(0,Math.Max(100,content.Length))}...");

                response.Close();
            }
            catch (Exception ex) {
                Console.WriteLine($"Request error: {ex.Message}");
            }
            finally
            {
                asyncResult.AsyncWaitHandle.Close();
            }
        }
    }
}
