﻿namespace ConcurrentCollections
{
    internal class User
    {
        public string Username { get; set; }
    }
}