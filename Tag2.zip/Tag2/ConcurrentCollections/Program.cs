﻿using System.Collections.Concurrent;
using System.Reflection.Metadata;

namespace ConcurrentCollections
{
    internal class Program
    {
        private ConcurrentDictionary<string, User> _users = new();

        private static ConcurrentQueue<User> _queue = new();

        private static ConcurrentBag<int> _bag = new();

        private static int _counter = 0;

        private static int threadCount = 10;

        static void Main(string[] args)
        {
            #region Queue
            //_queue.Enqueue(new User() { Username = "1." });
            ////_queue.TryDequeue(out User? user);

            //var consumer = Consume();

            //for (int i = 0; i < 10; ++i) {
            //    Console.WriteLine($"Adding User: {i}");
            //    _queue.Enqueue(new User() { Username = i.ToString() });
            //}

            //consumer.Wait();
            //Console.WriteLine("Queue ist leer");
            #endregion

            #region Bag
            _bag.Add(1);
            var success = _bag.TryTake(out int result);

            List<int> ints = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
            Parallel.ForEach(ints, _bag.Add);

            foreach(var v in _bag)
            {
                Console.WriteLine(v);
            }
            #endregion

            //Interlocked.Increment(ref _counter);
            //_counter += 10;
            //Interlocked.Add(ref _counter, 10);


            Console.WriteLine("------------------");

            Parallel.For(0, 200,
                (w) => Interlocked.Add(ref _counter, w)
                //(w) => {
                //    Console.WriteLine(w);
                //    _counter += w; }
            );

            Console.WriteLine("---------------------");
            Console.WriteLine(_counter);

            int x;
            x = 10; // ist atomar
            x = x + 10; // ist nicht atomar

            _counter = 0;

            ManualParallel();
        }

        public static void ManualParallel() {
            int start = 0;
            int end = 200;
            int rangePerThread = (end - start) / threadCount;

            Thread[] threads = new Thread[threadCount];

            for (int i = 0; i < threadCount; i++)
            {
                int threadStart = i * rangePerThread;
                int threadEnd = (i == threadCount - 1) ? end : threadStart + rangePerThread;

                threads[i] = new Thread(() =>
                {
                    for (int w = threadStart; w < threadEnd; w++)
                    {
                        Interlocked.Add(ref _counter, w);
                    }
                });

                threads[i].Start();
            }

            foreach (Thread t in threads)
            {
                t.Join();
            }

            Console.WriteLine("Final counter value: " + _counter);
        }

        public static async Task Consume()
        {
            while(_queue.Count > 0)
            {
                Console.WriteLine("Comsuming user:");
                _queue.TryDequeue(out User user);
                Console.Write(user.Username);
                await Task.Delay(500);
            }
        }

        public void AddOrUpdateUser(string username,User user)
        {
            _users.AddOrUpdate(username, user, (key, oldValue) => user);
        }

        public User GetOrCreate(string username)
        {
            return _users.GetOrAdd(username, key =>
            {
                // factory function will only be used once per key
                return new User();
            });
        }
    }
}
