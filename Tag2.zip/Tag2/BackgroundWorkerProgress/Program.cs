﻿using System.ComponentModel;

namespace BackgroundWorkerProgress
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Main Thread ID: {Thread.CurrentThread.ManagedThreadId}");
            var worker = new BackgroundWorker();

            // Enable progress reporting and cancellation
            worker.WorkerReportsProgress = true;
            worker.WorkerSupportsCancellation = true;

            // Set up event handler
            worker.DoWork += Worker_DoWork;
            worker.ProgressChanged += Worker_ProgressChanged;
            worker.RunWorkerCompleted += Worker_RunWorkerCompleted;

            // Start the worker
            worker.RunWorkerAsync("Some Parameter");

            Console.WriteLine("Worker started on backgrund thread.");

            Thread.Sleep(1000);
            Console.WriteLine("Cancelling operation...");
            worker.CancelAsync();

            // Wait for user input aka for completion
            Console.ReadLine();

        }

        private static void Worker_RunWorkerCompleted(object? sender, RunWorkerCompletedEventArgs e)
        {
            if(e.Cancelled)
            {
                Console.WriteLine("Work was cancelled.");
            }
            else if (e.Error is not null)
            {
                Console.WriteLine($"Error occured: {e.Error.Message}");
            }
            else
            {
                Console.WriteLine($"Work completed with result: {e.Result}");
            }
        }

        private static void Worker_ProgressChanged(object? sender, ProgressChangedEventArgs e)
        {
            Console.WriteLine($"Progress: {e.ProgressPercentage}%");
        }

        private static void Worker_DoWork(object? sender, DoWorkEventArgs e)
        {
            var worker = sender as BackgroundWorker;
            string parameter = e.Argument as string ?? "No parameter"; // if null use "No parameter" string
            string parameter2 = e.Argument is string p ? p : "No Parameter"; // same result different approach

            Console.WriteLine($"Worker Thread ID: {Thread.CurrentThread.ManagedThreadId}");

            Console.WriteLine($"Starting work with parameter: {parameter}");

            // Simulate work with progress reporting
            for (int i = 0; i <= 100; i += 10)
            {
                if(worker.CancellationPending)
                {
                    e.Cancel = true;
                    return;
                }

                //throw new Exception("Mu ha ha");

                Thread.Sleep(300);

                worker?.ReportProgress(i);
            }

            e.Result = "Work completed successfully!";
        }
    }
}
