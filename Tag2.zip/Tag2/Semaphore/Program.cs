﻿namespace Semaphore
{
    internal class Program
    {

        private static SemaphoreSlim semaphore = new SemaphoreSlim(1,1);

        private static Dictionary<string, string> _cache = new Dictionary<string, string>();

        static void Main(string[] args)
        {
            GetOrAddAsync("1");
            GetOrAddAsync("2");
            GetOrAddAsync("1");
            GetOrAddAsync("2");
            GetOrAddAsync("3");
            GetOrAddAsync("1");
            GetOrAddAsync("10");
            GetOrAddAsync("1");
            GetOrAddAsync("1");
        }

        public static async Task<string> GetOrAddAsync(string key)
        {
            if(_cache.TryGetValue(key,out var value)) 
                return value;

            await semaphore.WaitAsync();
            try
            {
                if (_cache.TryGetValue(key, out value))
                    return value;

                value = await FetchDataAsync(key);
                _cache[key] = value;
                return value;
            }
            finally
            {
                semaphore.Release();
            }
        }

        public static async Task<string> FetchDataAsync(string key)
        {
            await Task.Delay(300);
            return key + key; // fake wert
        }
    }
}
