﻿using System.Threading.Channels;
using System.Windows.Markup;

namespace ThreadPooling
{
    internal class Program
    {
        static int Ergebnis = 0;

        static bool ThreadFertig = false;

        static event Action<int> ErgebnisVorhanden;

        static void Main(string[] args)
        {
            Console.WriteLine($"Main thread {Thread.CurrentThread.ManagedThreadId}");

            ErgebnisVorhanden += (value) =>
            {
                Console.WriteLine($"Jetzt ist das Ergebnis fertig: {value}");
                ThreadFertig = true;
            };

            // Queue a work item to the thread pool
            ThreadPool.QueueUserWorkItem(new WaitCallback(DoWork), "Task data");
            ThreadPool.QueueUserWorkItem(new WaitCallback(DoWorkOnList), new List<int> { 10, 2, 3, 4, 5 });
            ThreadPool.QueueUserWorkItem(new WaitCallback(DoWorkOnList), new List<int> { 20, 30, 40 });

            for (int i = 0; i < 5; ++i)
            {
                Console.WriteLine($"Main thread work: {i}");
                Thread.Sleep(100);
            }

            // Need a way to know when the background thread is done
            // !!! This is just demonstration - not a good practice
            //Thread.Sleep(3000);

            while(!ThreadFertig)
            {
                Thread.Sleep(100);
            }

            Console.WriteLine($"Ergebnis von DoWorkOnList: {Ergebnis}");

            Console.WriteLine("All work done");
        }

        static void DoWork(object data)
        {
            string x = data switch
            {
                string value => value,
                _ => "unknown value"
            };

            Console.WriteLine(x);

            Console.WriteLine($"Worker Thread: {Thread.CurrentThread.ManagedThreadId}");

            // simulate work
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Worker thread working: {i}");
                Thread.Sleep(200);
            }

            Console.WriteLine("Worker thread completed");
        }

        static void DoWorkOnList(object data)
        {
            var liste = data is List<int> values ? values : [];
            var erste = liste.First();
            Console.WriteLine(erste);

            ErgebnisVorhanden?.Invoke(erste);

            Ergebnis = erste;
        }
    }
}
