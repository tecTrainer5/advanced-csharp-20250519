﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewFeatures.ReadonlyStruct
{
    readonly struct MyStructs
    {
        public readonly string SomeValue;

        public int Age { get; /*set;*/ }
        public int Id { get; init; }
    }
}
