﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewFeatures.ImplicitIndex
{
    internal class Implicit
    {
        public void Play() {
            var l = new Lib("test", 1)
            {
                Books = {
                    [1] = "Eine kurze Geschichte der Zeit",
                    [0] = "Don Carlos"

                }
            };

            var lImpl = new Lib("test", 1)
            {
                Books = {
                    [^1] = "Eine kurze Geschichte der Zeit", // [1]
                    [^2] = "Don Carlos" // [0]
                }
            };
            Console.Write(lImpl.Books[^1]);
        }

    }
}
