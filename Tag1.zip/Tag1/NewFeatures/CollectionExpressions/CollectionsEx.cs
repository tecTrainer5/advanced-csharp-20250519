﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewFeatures.CollectionExpressions
{
    internal class CollectionsEx
    {
        void Play()
        {
            List<string> daten = new List<string>() { "halllo", "du da", "usw" };
            var daten1 = new List<string>() { "halllo", "du da", "usw" };
            List<string> date3 = new (){ "asdf", "asdf" };
            List<string> date4 = [ "asdf", "asdf" ];
            //var date4 = [ "asdf", "asdf" ]; // geht nicht -> weil der Datentyp nicht eindeutig ist

            int[] values = [1,2,3,4,5,6,7];

            IEnumerable<int> ienum = [1, 2, 3];

            var list = new List<int>();

            var x = Enumerable.Empty<string>();

            Span<int> span = values[0..4];
            Span<int> spanFromExpressioin = [1, 2, 3, 4];
        }
    }
}
