﻿using InternallOpen;

namespace NewFeatures
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            var lib = new Lib("test",1);
            Console.WriteLine(lib.Name); // implicit ctor erzeugt kein Property

            var lib2 = new Lib2("test2",2);
            Console.WriteLine(lib2.Name);

            var p1 = new Person(string.Empty,1);
            p1.Alter = 12;


            var p1C = new Person("Alex",1);
            var p2C = new Person("Alex",1);

            if (p1C == p2C)
            {
                Console.WriteLine("gleich");
            }
            else
            {
                Console.WriteLine("nicht gleich");
            }

            p1C.Alter = 12;
            //p1C.Id = 10; // geht nicht

            var p3 = p1C with { }; // neue kopie ohne Äderung
            var p4 = p1C; // neue reference -> Änderug wirkt sich auch auf p1C aus
            p3.Alter = 100;

            var p2Clone = p1C with { Id = 10 };

            Console.WriteLine(p2Clone.Id);
            Console.WriteLine(p2Clone.Name);

            Tuple<int, int, string> tupleData = new (1, 2, "test");
            var data = tupleData.Item1; //1
            var data2 = tupleData.Item2; // 2
            var data3 = tupleData.Item3; // "test"

            List<Tuple<int, int, string>> x;

            Customer c1 = new (1, 2, "test");

            var list = new LinkedListe<int>([1, 2, 3]);
            Console.WriteLine(list);
        }
    }
}
