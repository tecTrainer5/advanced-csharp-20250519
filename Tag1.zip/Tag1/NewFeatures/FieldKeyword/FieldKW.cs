﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace NewFeatures.FieldKeyword
{
    internal class FieldKW
    {
        private string _name;

        public string Name
        {
            get => _name; set
            {
                _name = value ?? throw new ArgumentNullException(nameof(_name));
            }
        }

        public int Egal { get; set; }

        public int Alter
        {
            get;

            set
            {
                field = (value >= 0) ? value : 0;
            }
        }


    }
}
