﻿global using Customer = System.Tuple<int, int, string>;

namespace NewFeatures.TypeAlias;

using CustomerListe = List<Customer>; // ich kann jeden Typen ein Alias verpassen

class Play
{
    void Costomer() {
        Customer c = new(1, 2, "");
    }

    Customer CreateCustomer()
    {
        return new Customer(1, 2, "");
    }
}



