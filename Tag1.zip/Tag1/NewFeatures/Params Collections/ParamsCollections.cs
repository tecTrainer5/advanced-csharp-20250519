﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewFeatures.Params_Collections
{
    internal class ParamsCollections
    {
        public void Play()
        {
            //DoSomething("asdf", "asf");
            var values = new HashSet<string>() { "a", "b" };
            var valuesArray = new string[] { "a", "b" };

            DoSomething(values);
            DoSomething(valuesArray);
        }

        public void DoSomething(params string[] args) { }
        public void DoSomething(params HashSet<string> args) { }
        public void DoSomething(params List<string> args) { }
        public void DoSomething(params IEnumerable<string> args) { }
        public void DoSomething(params IList<string> args) { }
        public void DoSomething(params ICollection<string> args) { }
    }

}
