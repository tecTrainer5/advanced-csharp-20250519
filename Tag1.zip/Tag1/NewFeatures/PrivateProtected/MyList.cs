﻿using InternallOpen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewFeatures.PrivateProtected
{
    internal class MyList : LinkedListe<int>
    {
        public MyList(IEnumerable<int> values) : base(values)
        {
        }

        public override string ToString()
        {
            var builder  = new StringBuilder();
            //ConvertToString<int>(_root, builder); // verhindert durch private proteced
            return base.ToString();
        }


    }
}
