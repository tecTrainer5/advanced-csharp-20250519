﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewFeatures
{
    internal record Person(string Name,int Id)
    {
        public int Alter { get; set; }
    }
}
