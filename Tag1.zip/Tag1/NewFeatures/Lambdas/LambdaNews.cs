﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace NewFeatures.Lambdas
{
    internal class LambdaNews
    {
        public void Play()
        {
            var counter = (int a, int b) => 2;
            var dynCounter = (params int[] values) => values.Length;
            dynCounter(1, 2, 3, 4);
            dynCounter(1);


            CounterMethod(1, 2, 3, 4);
            CounterMethod(1, 2);

            var inkrement = (int a, int b = 1) => a + b;

            var r = inkrement(1); // 2
            var r2 = inkrement(1, 2); // 3


        }

        // alle müssen den selben typen haben
        public void CounterMethod(params int[] values) { 

        }

        public void CounterM(int a) { }
        public void CounterM(int a,int b) { }
        public void CounterM(int a,int b,int c) { }
    }
}
