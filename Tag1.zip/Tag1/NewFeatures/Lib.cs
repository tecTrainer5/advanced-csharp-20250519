﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewFeatures
{
    internal class Lib(string Name, int id)
    {
        //public Lib(string name, int id, string abc)
        //{
        //    this.Name = name;
        //    this.Id = id;
        //}

        public int Id { get; set; } = id; // equivalent für zuweisung in ctro

        public string Name { get; set; }

        //public void UseParams()
        //{
        //    name = Name; // kann auch zugewiesn werden
        //    Name = name;
        //}

        public List<string> Books { get; set; }
    }

    internal record Lib2(string Name,int Id)
    {

    }
}
