﻿namespace ExpressionMembers
{
    internal class Program
    {
        private static int age;

        const int PI = 3;

        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            var p1 = new Person(1);
            var p2 = new Person(2);
            Console.WriteLine(Person.Age);
            //Program.PI = 10;
        }

        public static int Age
        {
            get => age;
            set => age = value;
        }

        public static bool CanVote() => Age >= 16;
        public static bool CanVote2()
        {
            return Age >= 16;
        }

        public static void SetValue(int value) => age = value;


    }

    public class Person
    {
        private string _name = "asdf";

        public static int Age;

        // ctor as expression bodied member
        public Person(string name) => _name = name;

        public Person(int age) => Person.Age = age;
    }
}
