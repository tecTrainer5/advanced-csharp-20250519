﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Discards
{
    internal class Person
    {
        public int Age { get; set; } = 10;
        public int Id { get; set; } = 1;
        public string Name { get; set; } = "Maxi";
        public DateTime LastLogin { get; set; }

        public void Deconstruct(out int age, out int id, out string name, out DateTime lastLogin)
        {
            age = Age;
            id = Id;
            name = Name;
            lastLogin = LastLogin;
        }

        public void Deconstruct(out int id, out string name)
        {
            id = Id;
            name = Name;
        }
    }
}
