﻿namespace Discards
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            //int result;

            //if(int.TryParse("abc",out int resultDasWirdNichtBrauchen))
            if (int.TryParse("abc", out _))
            {
                //_ = 10;
                //var x = _;

                // kann trotzdem eine Variable sein (ermöglicht durch das var)
                var _ = 10;
                //Console.WriteLine(@_);


                // wird dank der Variable hier auch als Variable verwendet
                string egal;
                _ = GetValue(out egal);
            }


            var person = new Person();


            // id not used
            var (alter,_,name,lastLogin) = person;
            var (id, name2) = person;

            alter = 10;
            name = "exit";


        }

        // als parameter
        static int GetValue(out string _)
        {
            _ = "abc";
            return 10;
        }
    }
}
