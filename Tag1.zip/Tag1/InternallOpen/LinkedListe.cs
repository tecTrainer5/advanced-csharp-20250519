﻿using System.ComponentModel.Design.Serialization;
using System.Text;

namespace InternallOpen
{
    public class Node<T>
    {
        internal T Value { get; init; }
        internal Node<T>? Next { get; set; }
    }

    public class LinkedListe<T>
   
    {
        private protected Node<T>? _root;

        public LinkedListe(IEnumerable<T> values)
        {
            foreach (var item in values) {
                // try to implement me
                // alle werte in the liste einfügen
                var next = new Node<T>()
                {
                    Value = item,
                    Next = _root
                };

                _root = next;
            }    
        }

        // Nullable<T> == T?
        private protected void ConvertToString<T>(Node<T>? node,StringBuilder builder)
        {
            if (node is null)
            {
                return;
            }

            builder.AppendLine($"{node.Value} ->");
            ConvertToString(node.Next, builder);
        }

        public override string ToString()
        {
            var builder = new StringBuilder();
            ConvertToString(_root, builder);
            return builder.ToString();
        }
    }
}
