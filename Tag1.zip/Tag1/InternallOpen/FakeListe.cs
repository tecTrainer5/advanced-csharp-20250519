﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InternallOpen;

internal class FakeListe : LinkedListe<int>
{
    public FakeListe(IEnumerable<int> values) : base(values)
    {
    }

    public override string ToString()
    {
        var builder = new StringBuilder();
        ConvertToString<int>(_root, builder); // ist keine unterschied aber ist moeglich weil im selben Assembly
        return builder.ToString();
    }
}
