﻿using System.Data.Common;

namespace PatternMatching
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            //if(args == null)

            if (args is null) // ist bereits pattern matching
            {

            }
        }

        static void GetType(object obj)
        {
            if (obj is string)
            {
                Console.WriteLine("string");
            }

            var typeName = obj switch
            {
                string => "string",
                float => "float",
                int => "int",
                _ => "unbekannt"
            };

            Console.WriteLine(typeName);
        }

        static void GetShape(IShape shape)
        {
            var shapeName = shape switch
            {
                Circle => "Circle",
                Rectangle => "Recangle",
                _ => "Wrong Shape"
            };

            IShape shape2 = new Circle();

            if (shape2 is (Circle or Rectangle))
            {
                // Add code here
            }

            object greeting = "Hello, World!";
            //if (greeting is string message)
            //{
            //    message.ToUpper();
            //}

            var x = greeting is string message ? message.ToUpper() : string.Empty;

            //string y;
            //if (greeting is string message)
            //{
            //    y = message;
            //}
            //else
            //{
            //    y = string.Empty;
            //}

            Console.WriteLine(shapeName);
        }

        public interface IShape { }
        public class Circle : IShape { }
        public class Rectangle : IShape { }

        string Choice(int choice) => choice switch
        {
            1 => "You chose 1",
            2 => "You chose 2",
            _ => "You made an unknown choice"
        };

        string GetCalendarSeason(DateTime date) => date.Month switch
        {
            >= 3 and < 6 => "Spring",
            >= 6 and < 9 => "Summer",
            >= 9 and < 12 => "Authmn",
            12 or (>= 1 and < 3) => "Winter",
            _ => "Really?"
        };

        class Person
        {
            public int Age { get; set; }
            public int Height { get; set; } // in cm

            public string Name { get; set; }
            public string? Address { get; set; }

            public string Role { get; set; } // z.B. "Admin" oder "Manager" oder "Unknown"

            public void Deconstruct(out int age, out int height)
            {
                age = Age;
                height = Height;
            }
        }

        //public record Person(int Age,int Height);

        string CategorizePerson(Person person) => person switch
        {
            var (age,height) when age < 18 && height < 160 => "Young and short",
            var (age, height) when age < 18 && height >= 160 => "Young and tall",
            var (age, height) when age >= 18 && height < 160 => "Adult and short",
            var (age, height) when age >= 18 && height >= 160 => "Adult and tall",
            _ => "Invalid person"
        };

        string CatgorizePerson1(Person person) => person switch
        {
            { Age: < 18 } and { Height: < 160 } => "Yount and short",
            { Age: < 18 } and { Height: >= 160 } => "Young and tall",
            { Age: >= 18 } and { Height: < 160 } => "Adult and short",
            { Age: >= 18 } and { Height: >= 160 } => "Adult and tall",
        };

        string CatgorizePerson2(Person person) => person switch
        {
           Person { Age: < 18 } and { Height: < 160 } => "Yount and short",
           Person { Age: < 18 } and { Height: >= 160 } => "Young and tall",
           Person { Age: >= 18 } and { Height: < 160 } => "Adult and short",
           Person { Age: >= 18 } and { Height: >= 160 } => "Adult and tall",
        };

        // Property Pattern
        bool IsValidPerson(Person person) => person is { 
            Age: >= 18,
            Name: { Length: > 0 },
            Address: not null,
            Role: "Admin" or "Manager"
        };
        // muss mind 18
        // name laenge mind 1
        // adressse nicht null
        // rolle soll in "Admin" oder "Manager"

        void ListPattern() {
            var numbers = new int[] { 1, 2, 3, 4, 5 };

            Console.WriteLine(numbers is [1, 2, 3, ..]);     // True -> .. ist rest kann aber auch nicht vorhanden sein aka leer 
            Console.WriteLine(numbers is [> 0, _, < 4, ..]); // True
            Console.WriteLine(numbers is [.., 5]);           // True
            Console.WriteLine(numbers is [.., 4, 5 or 6]);   // True
            Console.WriteLine(numbers is [.., > 0 and < 6]); // True
            Console.WriteLine(numbers is [not 2, ..]);       // True

        }

        string CategorizePerson(IList<Person> person)
        {
            return person switch
            {
                [var (age, height, address), _, Person, ..]
                    when age >= 18 && height < 160 && address.City is "New York"
                        => "The first person is adult and short New Yorker",

                [_, { Age: >= 18, Height: >= 160, Address.City: "New York" }, ..]
                                => "The second person is adult and tall New Yorker",

                _ => "Invalid person"
            };
        }

        void CatchMe() {
            try
            {
                // Some code that may throw exceptions
            }
            catch (Exception ex) when (ex is ArgumentNullException) {
                Console.WriteLine("Caught an argument exception.");
            }
            catch (Exception ex ) when (ex is DbException and { ErrorCode: 2627 }) {
                Console.WriteLine("Caugt a DB excpetions for a duplacte key.");
            }
            catch (Exception ex) when (ex is DbException and { ErrorCode: 1234 })
            {
                Console.WriteLine("Caugt a DB excpetions for a any other.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Caught an unexpteced exception: {ex.GetType().Name}");
            }
        }

    }
}
