﻿namespace Defaults; // file scoped namespace

class Program
{
    public static void Main()
    {
        int value = default(int);
        int value2 = default; // null

        string text = default;

        Person p1 = default;

        int x = default;
        DoSomething(x);
        DoSomething(default);
        DoSomething(default(float));
    }
    static void DoSomething(int value) { }
    static void DoSomething(float value) { }
}




class Person {
    string NameEgal;
}

class Node<T>
    where T : notnull
{
    private T value;

    public Node(T value)
    {
        this.value = value;
    }

    public Node()
    {
        value = default; // abhangig von T was der default wert ist
    }
}

