﻿using System.IO.Compression;
using System.Reflection.Metadata;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace SecretJson
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // af@mit.at

            Console.WriteLine("Hello, World!");

            var result = JsonSerializer.Serialize(new User());

            using var stream = new MemoryStream(Encoding.UTF8.GetBytes(result));
            using var archive = new ZipArchive(stream,ZipArchiveMode.Create,true);
            var file = archive.CreateEntry("foo.txt");
            using var entry = file.Open();
            using var writer = new StreamWriter(entry);
            writer.Write(result);


        }
    }
}
