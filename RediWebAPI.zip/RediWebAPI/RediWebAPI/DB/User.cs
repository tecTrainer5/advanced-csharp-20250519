﻿namespace RediWebAPI.DB
{
    public class User
    {
        public int Id { get; set; }

        public string EMail { get; set; }
    }
}
