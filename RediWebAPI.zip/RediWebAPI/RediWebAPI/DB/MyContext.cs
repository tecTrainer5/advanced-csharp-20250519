﻿using Microsoft.EntityFrameworkCore;

namespace RediWebAPI.DB
{
    public class MyContext : DbContext
    {
        public DbSet<User> Users { get; set; }
    }
}
